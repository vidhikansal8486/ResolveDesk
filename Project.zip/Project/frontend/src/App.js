import { useState } from "react";
import "./App.css";

import Login from "./pages/Login";
import Register from "./pages/Register";
import SubmitGrievance from "./pages/SubmitGrievance";
import ViewGrievances from "./pages/ViewGrievances";

function App() {

  const [page, setPage] = useState("login");

  return (
    <div className="app">

      <div className="navbar">
        Public Grievance Redressal System
      </div>

      <div className="button-container">
        <button onClick={() => setPage("login")}>Login</button>
        <button onClick={() => setPage("register")}>Register</button>
        <button onClick={() => setPage("submit")}>Submit</button>
        <button onClick={() => setPage("view")}>View</button>
      </div>

      {page === "login" && <Login />}
      {page === "register" && <Register />}
      {page === "submit" && <SubmitGrievance />}
      {page === "view" && <ViewGrievances />}

    </div>
  );
}

export default App;