import { useState } from "react";
import { jwtDecode } from "jwt-decode";

function SubmitGrievance() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Get token from localStorage
    const token = localStorage.getItem("token");

    if (!token) {
      alert("Please login first");
      return;
    }

    // Decode token and extract userId
    const decoded = jwtDecode(token);
    const userId = decoded.id;
    console.log(decoded);
    console.log(userId);

    const response = await fetch(
      "http://localhost:5000/api/grievances/create",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title,
          description,
          category,
          userId: userId,
        }),
      }
    );

    const data = await response.json();

    if (response.ok) {
      alert("Grievance submitted successfully");

      setTitle("");
      setDescription("");
      setCategory("");
    } else {
      alert(data.message || "Failed to submit grievance");
    }
  };

  return (
    <div>
      <h2>Submit Grievance</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <br />
        <br />

        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <br />
        <br />

        <input
          type="text"
          placeholder="Category (optional)"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        />
        <br />
        <br />

        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default SubmitGrievance;