import { useEffect, useState } from "react";
import { jwtDecode } from "jwt-decode";

function ViewGrievances() {

  const [grievances, setGrievances] = useState([]);

  useEffect(() => {

    const fetchGrievances = async () => {

      try {

        // Get token
        const token = localStorage.getItem("token");

        if (!token) {
          alert("Please login first");
          return;
        }

        // Decode token
        const decoded = jwtDecode(token);

        const userId = decoded.id;

        // Fetch only logged-in user's grievances
        const res = await fetch(
          `http://localhost:5000/api/grievances/user/${userId}`
        );

        const data = await res.json();

        setGrievances(data);

      } catch (error) {

        console.log(error);

      }

    };

    fetchGrievances();

  }, []);




  return (
    <div>

      <h2>My Grievances</h2>

      {grievances.length === 0 ? (

        <p>No grievances found</p>

      ) : (

        grievances.map((g) => (

          <div
            key={g._id}
            style={{
              border: "1px solid black",
              margin: "10px",
              padding: "10px",
            }}
          >

            <h3>{g.title}</h3>

            <p>{g.description}</p>

            <p>Category: {g.category}</p>

            <p>Status: {g.status}</p>

          </div>

        ))

      )}

    </div>
  );
}

export default ViewGrievances;