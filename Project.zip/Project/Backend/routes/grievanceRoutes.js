const express = require("express");
const router = express.Router();

const Grievance = require("../models/Grievance");


// ================= CREATE GRIEVANCE =================
router.post("/create", async (req, res) => {

  try {

    const { title, description, category, userId } = req.body;

    const grievance = new Grievance({
      title,
      description,
      category,
      userId,
    });

    await grievance.save();

    res.status(201).json({
      message: "Grievance submitted successfully",
    });

  } catch (error) {

    res.status(500).json({
      error: error.message,
    });

  }

});


// ================= GET ALL GRIEVANCES =================
router.get("/", async (req, res) => {

  try {

    const grievances = await Grievance.find();

    res.json(grievances);

  } catch (error) {

    res.status(500).json({
      error: error.message,
    });

  }

});


// ================= GET USER GRIEVANCES =================
router.get("/user/:userId", async (req, res) => {

  try {

    console.log("PARAM USER ID:", req.params.userId);

    const grievances = await Grievance.find({
      userId: req.params.userId.toString(),
    });

    console.log("FOUND GRIEVANCES:", grievances);

    res.json(grievances);

  } catch (error) {

    res.status(500).json({
      error: error.message,
    });

  }

});


// ================= UPDATE STATUS =================
router.put("/:id", async (req, res) => {

  try {

    const grievance = await Grievance.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    res.json(grievance);

  } catch (error) {

    res.status(500).json({
      error: error.message,
    });

  }

});


module.exports = router;